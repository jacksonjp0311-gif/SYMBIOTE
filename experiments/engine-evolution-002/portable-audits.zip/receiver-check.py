from pathlib import Path,PurePosixPath
import os,sys,json,hashlib,zipfile,uuid,runpy,builtins,io,socket,subprocess,stat,traceback
sys.dont_write_bytecode=True
base=Path(os.environ['TEMP'])/('evo2-receiver-relocation-'+uuid.uuid4().hex);base.mkdir()
archive=Path(r'C:\Users\jacks\Documents\Codex\2026-10-26\codex-master-directive-symbiote-symbiotic-adaptive\experiments\engine-evolution-002\evidence.zip')
source=Path(os.environ['TEMP'])/'evo2-receiver-portable.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
zipsha=sha(archive);scripts=sha(source)
with zipfile.ZipFile(archive)as z:
 infos=z.infolist();assert len({i.filename for i in infos})==len(infos)
 assert sum(i.file_size for i in infos)<=134217728
 for i in infos:
  rel=PurePosixPath(i.filename);assert not rel.is_absolute()and '..'not in rel.parts and '\\'not in i.filename and ':'not in i.filename and not stat.S_ISLNK(i.external_attr>>16)
  p=base.joinpath(*rel.parts);p.parent.mkdir(parents=True,exist_ok=True)
  if i.is_dir():p.mkdir(exist_ok=True)
  else:p.write_bytes(z.read(i))
root=base/'run';output=base/'receiver-replay.json'
before={p.relative_to(root).as_posix():sha(p)for p in root.rglob('*')if p.is_file()}
assert not list(root.rglob('*.exe'))
blocked=[r'C:\Users\jacks\AppData\Local\Temp\evo2-run-bb1b88e',r'C:\Users\jacks\AppData\Local\Temp\evo2-build-bb1b88e',r'C:\Users\jacks\Documents\Codex\2026-10-26\codex-master-directive-symbiote-symbiotic-adaptive']
blocked=[s.replace('\\','/').casefold().rstrip('/')for s in blocked];attempts=[];original={}
def check(p):
 try:s=os.fspath(p).replace('\\','/').casefold().rstrip('/')
 except TypeError:return
 if any(s==x or s.startswith(x+'/')for x in blocked):attempts.append('original-path');raise AssertionError('original-host filesystem access denied')
def patch(obj,name,fn):original[(obj,name)]=getattr(obj,name);setattr(obj,name,fn)
for obj,names in [(Path,['open','stat','lstat','resolve']),(os,['stat','lstat','open']),(builtins,['open']),(io,['open'])]:
 for name in names:
  old=getattr(obj,name)
  def guarded(p,*a,_old=old,**kw):check(p);return _old(p,*a,**kw)
  patch(obj,name,guarded)
def forbidden(*a,**kw):attempts.append('process/network');raise AssertionError('process/network action denied')
for obj,names in[(subprocess,['Popen','run','call','check_call','check_output']),(socket,['socket','create_connection','getaddrinfo']),(os,['system','startfile'])]:
 for name in names:
  if hasattr(obj,name):patch(obj,name,forbidden)
status=None;err=None
try:
 sys.argv=[str(source),'--root',str(root),'--output',str(output)]
 try:runpy.run_path(str(source),run_name='__main__')
 except SystemExit as e:status=e.code
except BaseException:err=traceback.format_exc()
finally:
 for(obj,name),old in original.items():setattr(obj,name,old)
after={p.relative_to(root).as_posix():sha(p)for p in root.rglob('*')if p.is_file()}
replay=json.loads(output.read_text())if output.exists()else{}
receipt=dict(schema='symbiote.receiver-portable-replay-proof/1',status='PASS'if status==0 and not err and not attempts and before==after else'HOLD',archive_sha256=zipsha,portable_script_sha256=scripts,extracted_root=str(root),replay_receipt=str(output),replay_receipt_sha256=sha(output)if output.exists()else None,replay_status=replay.get('status'),original_path_and_process_network_attempts=attempts,raw_run_files=len(before),raw_files_unchanged=before==after,excluded_native_executables_available=False,source_byte_verification=replay.get('source_byte_verification'),local_binary_byte_verification=replay.get('local_binary_byte_verification'),artifact_members_rehashed=replay.get('artifact_members_rehashed'),excluded_executable_members=list(replay.get('excluded_executable_members',{})),error=err or replay.get('error'))
proof=Path(os.environ['TEMP'])/'evo2-receiver-portable-proof.json';proof.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt,indent=2));print('PROOF_SHA',sha(proof))
