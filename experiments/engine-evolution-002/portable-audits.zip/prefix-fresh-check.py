import hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path(r'C:\Users\jacks\Documents\Codex\2026-10-26\codex-master-directive-symbiote-symbiotic-adaptive')
PUBLIC=ROOT/'experiments/engine-evolution-002'
OUT=Path(os.environ['TEMP'])/'evo2-portable-bb1b88e'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 assert not OUT.exists()
 OUT.mkdir()
 summary=json.loads((PUBLIC/'summary.json').read_text(encoding='utf-8'))
 manifest=json.loads((PUBLIC/'manifest.json').read_text(encoding='utf-8'))
 assert sha(PUBLIC/'evidence.zip')==summary['evidence']['archive_sha256']
 assert sha(PUBLIC/'manifest.json')==summary['evidence']['manifest_sha256']
 expected={v['path']:v for v in manifest['files']}
 with zipfile.ZipFile(PUBLIC/'evidence.zip') as archive:
  assert set(archive.namelist())==set(expected)
  for name in archive.namelist():
   relative=PurePosixPath(name)
   assert not relative.is_absolute() and not set(relative.parts)&{'..','.'}
   path=OUT.joinpath(*relative.parts)
   assert OUT.resolve() in path.resolve().parents
   raw=archive.read(name)
   assert len(raw)==expected[name]['bytes'] and hashlib.sha256(raw).hexdigest()==expected[name]['sha256']
   path.parent.mkdir(parents=True,exist_ok=True)
   with path.open('xb') as stream:stream.write(raw)
 commands=[('prefix',[str(OUT/'audits/evo2-prefix-audit-bb1b88e.py'),'--run-root',str(OUT/'run'),'--build-proof',str(OUT/'build/build-proof.json'),'--output',str(OUT/'prefix-replay.json')]),
 ('fresh',[str(OUT/'audits/evo2-fresh-audit-bb1b88e.py'),'--root',str(OUT/'run'),'--registration-sha256',summary['registration_sha256'],'--build-proof',str(OUT/'build/build-proof.json'),'--output',str(OUT/'fresh-replay.json')])]
 for label,args in commands:
  proc=subprocess.run([sys.executable,'-B',*args],capture_output=True,timeout=30)
  (OUT/f'{label}.stdout').write_bytes(proc.stdout);(OUT/f'{label}.stderr').write_bytes(proc.stderr)
  assert proc.returncode==0, f'{label} failed: '+proc.stderr.decode('utf-8')
  print(json.dumps(dict(label=label,report_sha256=sha(OUT/f'{label}-replay.json'),status=json.loads((OUT/f'{label}-replay.json').read_text())['status'])))
 print(json.dumps(dict(extracted=str(OUT),verified_files=len(expected),native_processes_launched=0)))
if __name__=='__main__':main()
