"""Independent data-only Protocol 002 fresh-task consumer. Never launches targets.
Portable use: --root EXTRACTED_RUN --registration-sha256 PIN --build-proof FILE --output NEW_JSON.
Optional --local-bindings also verifies the original pinned executable bytes;
optional --repository checks the original native-source manifest and adapter bytes.
Original absolute artifact paths are mapped lexically to --root; no fallback.
"""
import argparse,hashlib,json,os
from pathlib import Path,PureWindowsPath,PurePosixPath
SOURCE='bb1b88eaa771be5e201ccfcfe93840c6750eb9d7'
REG='89241bf8b120508053a91966e57c02f70343a1f8a3e8aafe3d8a59ec1b385409'
PROTO='SYMBIOTE-ENGINE-EVOLUTION-002'
CASES=[(37,0),(232,1),(146,1),(86,0)]
checked={}
def need(ok,message):
 if not ok:raise RuntimeError(message)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def h(raw):return hashlib.sha256(raw).hexdigest()
def sha(path):
 value=hashlib.sha256()
 with Path(path).open('rb')as stream:
  for block in iter(lambda:stream.read(1048576),b''):value.update(block)
 return value.hexdigest()
def pairs(items):
 d={}
 for key,value in items:need(key not in d,'duplicate JSON field');d[key]=value
 return d
def raw(path):
 path=Path(path);before=path.stat();value=path.read_bytes();after=path.stat()
 need((before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino),'file changed while read')
 checked[str(path)]={'bytes':len(value),'sha256':h(value)};return value
def load(path):return json.loads(raw(path),object_pairs_hook=pairs)
def inventory(root):
 result={}
 for path in sorted(root.rglob('*')):
  info=path.lstat();need(not path.is_symlink() and not getattr(info,'st_file_attributes',0)&0x400,'linked evidence refused')
  if path.is_file():result[path.relative_to(root).as_posix()]={'bytes':info.st_size,'sha256':sha(path)}
 return result
def typed_chain(path,knowledge=False):
 data=raw(path);need(data.endswith(b'\n'),'truncated ledger');previous='0'*64;rows=[]
 for seq,line in enumerate(data.splitlines()):
  row=json.loads(line,object_pairs_hook=pairs);need(row['sequence']==seq and row['previous']==previous,'ledger sequence')
  value=[seq,previous,row['payload']] if knowledge else {key:row[key]for key in ('sequence','previous','payload')}
  expected=h(json.dumps(value,separators=(',',':'),ensure_ascii=False).encode());need(expected==row['sha256'],'typed native ledger hash');previous=expected;rows.append(row)
 return rows
def record_hash(record):
 value={key:record[key]for key in ('id','revision','source','scope','schema_fingerprint','payload','provenance')};value['payload']=json.loads(canonical(value['payload']))
 return h(json.dumps(value,separators=(',',':'),ensure_ascii=False).encode())
class Rows:
 def __init__(self):
  self.basis=[None]*9;self.observations=[];self.work=dict(row_checks=0,row_xors=0,row_insertions=0,query_candidates=0,strategy_predictions=0)
 def reduce(self,row,rhs):
  for bit,basis in enumerate(self.basis):
   self.work['row_checks']+=1
   if row&(1<<bit) and basis is not None:row^=basis[0];rhs^=basis[1];self.work['row_xors']+=1
  return row,rhs
 def observe(self,input,output):
  if (input,output) in self.observations:return
  row,rhs=self.reduce(input|256,output);need(row or not rhs,'contradictory observation')
  if row:
   pivot=(row&-row).bit_length()-1
   for i,basis in enumerate(self.basis):
    self.work['row_checks']+=1
    if basis is not None and basis[0]&(1<<pivot):self.basis[i]=(basis[0]^row,basis[1]^rhs);self.work['row_xors']+=1
   self.basis[pivot]=(row,rhs);self.work['row_insertions']+=1
  self.observations.append((input,output))
 def choose(self,policy):
  inputs=[0,*[1<<bit for bit in range(8)]] if policy=='rank-basis-min/v1' else [i for i in range(256)if i not in [x for x,_ in self.observations]]
  first=None
  for value in inputs:
   self.work['query_candidates']+=1
   if self.reduce(value|256,0)[0] and first is None:
    first=value
    if policy=='rank-basis-min/v1':break
  return first
 def predict(self,input):
  row,rhs=self.reduce(input|256,0);need(row==0,'model must be identified before prediction');return rhs
 def check(self,snapshot):
  rank=sum(value is not None for value in self.basis)
  need(snapshot['work']==self.work and snapshot['work_units']==sum(self.work.values()),'independently replayed actual GF2 operations')
  need(snapshot['rank']==rank and snapshot['hypotheses']==1<<(9-rank) and snapshot['free_parameters']==9-rank,'exact affine support/rank')
  need(snapshot['accepted_observations']==len(self.observations) and snapshot['status']=='supported' and snapshot['physical_certificate_authorized'] is False,'conditional snapshot')
 def model(self):
  need(all(self.basis) and all(row[0]==1<<i for i,row in enumerate(self.basis)),'full rank RREF')
  return {'kind':'affine','width':8,'coefficients':sum(self.basis[i][1]<<i for i in range(8)),'bias':bool(self.basis[8][1])}
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',required=True,type=Path);parser.add_argument('--registration-sha256',required=True);parser.add_argument('--build-proof',required=True,type=Path);parser.add_argument('--output',required=True,type=Path);parser.add_argument('--repository',type=Path);parser.add_argument('--local-bindings',action='store_true');args=parser.parse_args()
 root=args.root.resolve(strict=True);need(not args.output.exists() and root not in args.output.resolve().parents,'fresh outside-corpus output required');before=inventory(root)
 reg=load(root/'registration.json');need(args.registration_sha256==REG and sha(root/'registration.json')==REG,'external registration pin')
 need(reg['source_commit']==SOURCE and reg['protocol']==PROTO and reg['cases']==[{'width':8,'mask':m,'bias':b}for m,b in CASES] and reg['fresh_inputs']==32,'frozen workload/source')
 build=load(args.build_proof);need(build['source_commit']==SOURCE and build['status']=='PASS_BUILD_BYTES_PRESERVED' and build['source_manifest']==reg['source_manifest'],'build/source manifest binding')
 for role in ('native','observer'):
  need(reg['versions'][role]['build_source_commit']==SOURCE,'pre-admitted executable source stamp')
 if args.local_bindings:
  for role in ('native','observer','memory_test','service_test'):need(sha(reg[role]['path'])==reg[role]['sha256'],'actual preserved executable bytes')
 if args.repository:
  for row in reg['source_manifest']['files']:need((args.repository/row['path']).stat().st_size==row['bytes'] and sha(args.repository/row['path'])==row['sha256'],'unchanged source manifest member')
  need(sha(args.repository/'docs/ENGINE_EVOLUTION_PROTOCOL_002.md')==reg['protocol_sha256'] and sha(args.repository/'adapters/switchbox_source.py')==reg['source_adapter']['sha256'],'protocol/adapter pin')
 report=load(root/'fresh-tasks/fresh-task-report.json');need(report['status']=='PASS_CONDITIONAL_FRESH_REUSE' and len(report['cases'])==4,'four closed fresh cases')
 outer=load(root/'evolution-report.json');need(sha(root/'evolution-report.json')=='a0dcb9752c578041e745489b80198f42011fd788e377eed674e84b7d45f1cf68' and outer['status']=='PASS_ENGINEERING_ONLY' and outer['registration_sha256']==REG,'outer result binding')
 original=PureWindowsPath(reg['artifacts'])
 def mapped(value):
  path=PureWindowsPath(value);need(path.is_absolute() and '..' not in path.parts,'safe absolute provenance');relative=path.relative_to(original);result=root.joinpath(*relative.parts);need(result.is_file(),'selected original artifact path must map to current corpus');return result
 summaries=[];owners=set();process_count=0
 for index,(mask,bias) in enumerate(CASES):
  case=root/f'fresh-tasks/case-{index}';graded=load(case/'graded-result.json');need(graded==report['cases'][index],'case report exact outer copy')
  reveal=load(case/'evaluation-reveal.json');commit=load(case/'predictions-committed.json');opening=load(case/'source-opening-after-predictions.json')
  need(opening['predictions_committed_sha256']==sha(case/'predictions-committed.json'),'opening references prior prediction commitment')
  truth=opening['opening'];need(truth['width']==8 and truth['mask']==mask and truth['bias']==bias and h(canonical(truth))==opening['commitment'],'verifiable opaque commitment opening')
  arm_results=[];observed_union=set()
  for arm in ('reference','rank','isolated','cache'):
   target=case/arm;freeze=load(target/'freeze.json');pred=load(target/'predictions.json');desc=load(target/'approved-descriptor.json');summary=load(target/'source-summary.json')
   need(not {'mask','bias','outputs','token','token_file'}&desc.keys(),'no wiring/bearer exposed in approved client descriptor')
   observed=freeze['observed_inputs'];need(observed==[0,1,2,4,8,16,32,64,128,3] and len(set(observed))==10,'nine independent training inputs and one distinct validation')
   observed_union.update(observed);need(reveal['freezes'][arm]==sha(target/'freeze.json')==pred['freeze_sha256'],'freeze/reveal/prediction linkage')
   committed=[v for v in commit['predictions']if v['arm']==arm];need(len(committed)==1 and mapped(committed[0]['path'])==target/'predictions.json' and committed[0]['sha256']==sha(target/'predictions.json'),'actual unchanged prediction commitment')
   identity=typed_chain(target/'state/ledger.jsonl');need(len(identity)==1 and identity[0]['payload']['event']=='genesis','unchanged prepared owner identity')
   owner=identity[0]['payload']['identity'];need(owner not in owners,'separate arm identities');owners.add(owner)
   need(load(target/'prepare.stdout')['identity']==owner,'actual prepared identity')
   wire=0;request_bytes=0;previous='0'*64;actual=[]
   transcript=raw(target/'source-observations.jsonl');need(transcript.endswith(b'\n'),'complete source transcript')
   for seq,line in enumerate(transcript.splitlines()):
    row=json.loads(line,object_pairs_hook=pairs);provided=row.pop('sha256');need(row['sequence']==seq and row['previous']==previous and h(canonical(row))==provided,'source transcript chain');previous=provided
    frame=row['response_frame_utf8'].encode();need(row['send_completed'] is True and row['response_bytes']==len(frame) and row['response_sha256']==h(frame),'actual emitted source response bytes')
    value=json.loads(frame,object_pairs_hook=pairs);need(set(value)=={'schema','source_id','scope','epoch','commitment','width','sequence','input','output'} and value['schema']=='symbiote.switchbox-response/1','closed one-observation response')
    need(all(value[k]==desc[k]for k in ('source_id','scope','epoch','commitment','width')) and value['commitment']==opening['commitment'] and value['sequence']==seq and value['input']==observed[seq],'actual response identity/input/epoch')
    expected=(sum(((value['input']>>i)&1)*((mask>>i)&1)for i in range(8))%2)^bias
    need(type(value['output']) is int and value['output']==expected==row['output'],'independent switchbox arithmetic')
    actual.append({'sequence':seq,'input':value['input'],'output':value['output']});wire+=len(frame)
    # Private grants are fixed64hex by frozen supervisor. Recompute size without revealing any bearer.
    request=dict(schema='symbiote.switchbox-request/1',source_id=desc['source_id'],scope=desc['scope'],epoch=desc['epoch'],sequence=seq,input=value['input'],token='x'*64)
    request_bytes+=len(json.dumps(request,separators=(',',':')).encode())+1
   need(len(actual)==10 and summary['source_calls']==10 and summary['denied_requests']==0 and summary['transcript_head']==previous and summary['owner_stopped'] and summary['fault']=='none','actual bounded source completion')
   wire+=request_bytes
   produced=next(v for v in graded['arms']if v['arm']==arm)
   for call in produced['process_calls']:
    process_count+=1;need(load(target/call['process_receipt'])==call and call['exit_code']==0 and call['outcome']=='completed' and call['cleanup_verified'] and not call['output_truncated'],'owned native process receipt')
    need(all(sha(target/call[k])==call[k+'_sha256'] and (target/call[k]).stat().st_size==call[k+'_bytes']for k in ('stdout','stderr')),'bounded original process streams')
    need(call['argv'][0]==reg['native' if call['label']=='prepare' else 'observer']['path'],'selected registered executable')
   if arm=='cache':
    need(freeze['owner']==owner and freeze['entries']=={str(v['input']):v['output']for v in actual} and freeze['plaintext_bytes']==wire,'cache contains actual observations only')
    need(all(v['prediction'] is None for v in pred['predictions']),'cache abstention on unanswered inputs');learn_work=reopen_work=0
   else:
    need(freeze['identity']==owner and freeze['source']==pred['source'] and all(freeze['source'][k]==desc[k]for k in ('source_id','scope','epoch','commitment','width')),'frozen source descriptor binding')
    need(freeze['build_source_commit']==pred['build_source_commit']==SOURCE and freeze['observations']==actual and raw(target/'state/freeze.json')==raw(target/'freeze.json'),'exact native source/freeze bytes')
    need(freeze['source_queries']==10 and freeze['source_io']==dict(attempts=10,connections=10,request_bytes=request_bytes,response_bytes=wire-request_bytes),'actual source work and byte counters')
    policy='finite-domain-scan/v1' if arm=='reference' else 'rank-basis-min/v1';need(freeze['query_policy']==pred['query_policy']==policy,'selected versioned policy')
    learner=Rows();events=freeze['events'];need(len(events)==19,'complete training/model/validation trace')
    for seq,observation in enumerate(actual[:9]):
     need(learner.choose(policy)==observation['input'],'exact independently constructed query choice')
     event=events[2*seq];need(event['phase']=='OBSERVE' and event['details']['observation']==observation,'actual active observation event');learner.check(event['details']['before'])
     learner.observe(observation['input'],observation['output']);event=events[2*seq+1];need(event['phase']=='MODEL' and event['details']['received_hint_used'] is False,'no imported hint');learner.check(event['details']['snapshot'])
    need(learner.predict(actual[9]['input'])==actual[9]['output'] and events[18]['phase']=='VERIFY' and events[18]['details']['observation']==actual[9] and events[18]['details']['conditional_prediction']==actual[9]['output'],'distinct heldout check')
    learner.check(freeze['snapshot']);learn_work=sum(learner.work.values());need(freeze['gf2_work_units']==learn_work,'all acquisition GF2 work')
    model=learner.model();need(model==freeze['record']['payload'] and model['coefficients']==mask and model['bias']==bool(bias),'identified model from actual equations')
    history=typed_chain(target/'state/knowledge.jsonl',True);need(len(history)==2 and history[0]['payload']['identity']==owner and history[1]['payload']['event']=='promote' and history[1]['payload']['record']==freeze['record'],'one actual durable promotion')
    need(freeze['record_sha256']==record_hash(freeze['record']) and pred['record_sha256']==freeze['record_sha256'] and pred['knowledge_before']==pred['knowledge_after']==freeze['knowledge_after']==dict(identity=owner,records=2,head_sha256=history[-1]['sha256']),'unchanged active retained model/history')
    provenance=json.loads(freeze['record']['provenance'],object_pairs_hook=pairs);need(provenance['observations']==actual and provenance['training_count']==9 and provenance['source']==freeze['source'] and provenance['snapshot']==freeze['snapshot'],'ledger-bound acquisition audit')
    evidence=history[1]['payload']['assessment']['evidence'];need(evidence['training_inputs']==observed[:9] and len(evidence['cases'])==1 and evidence['cases'][0]['input']==actual[9]['input'] and evidence['cases'][0]['expected']==actual[9]['output'],'actual distinct validation promotion evidence')
    need(history[1]['payload']['assessment']['cost_improved'] is False and freeze['baseline_kind']=='unknown','unknown baseline cannot become measured benefit')
    replay=Rows()
    for item in actual[:9]:replay.observe(item['input'],item['output'])
    need(replay.predict(actual[9]['input'])==actual[9]['output'] and pred['replay_gf2_work_units']==sum(replay.work.values()),'actual cold observation replay work')
    need(pred['source_queries']==0 and pred['source_contact_attempts']==0 and pred['labels_received'] is False and pred['learning_during_evaluation'] is False,'offline frozen prediction')
    need([v['input']for v in pred['predictions']]==reveal['inputs'] and pred['retained_prediction_calls']==32,'all new predictions committed')
    for value in pred['predictions']:need(value['basis']=='inferred' and value['conditional'] is True and value['physical_certificate_authorized'] is False and value['prediction']==replay.predict(value['input']),'fresh inferred answer before labels')
    replay.check(pred['snapshot']);reopen_work=sum(replay.work.values());need(pred['gf2_work_units']==reopen_work,'all cold/prediction GF2 operations')
    calls={v['label']:v for v in produced['process_calls']};need(calls['learn']['pid']!=calls['predict']['pid'] and load(target/'learn.stdout')['freeze_sha256']==sha(target/'freeze.json') and load(target/'predict.stdout')['receipts_sha256']==sha(target/'predictions.json'),'real OS process restart and native output commits')
   need([v['input']for v in pred['predictions']]==reveal['inputs'],'same revealed task sequence for all arms')
   vector=produced['complete_operation'];state_bytes=sum(p.stat().st_size for p in (target/'state').iterdir()if p.is_file())
   need(vector['source_calls']==10 and vector['inference_and_validation_gf2']==learn_work and vector['reopen_and_prediction_gf2']==reopen_work and vector['prediction_calls']==32 and vector['plaintext_bytes']==wire and vector['retained_state_bytes']==state_bytes and vector['source_audit_bytes']==len(transcript),'independently derived complete declared cost vector')
   correct=sum(type(v['prediction'])is int and v['prediction']==((sum(((v['input']>>i)&1)*((mask>>i)&1)for i in range(8))%2)^bias)for v in pred['predictions']);abstain=sum(v['prediction']is None for v in pred['predictions'])
   need((correct,abstain)==((0,32)if arm=='cache'else(32,0)) and produced['correct']==correct and produced['abstentions']==abstain,'independent grading/control outcome')
   arm_results.append(dict(arm=arm,correct=correct,abstentions=abstain,source_calls=10,learning_gf2=learn_work,reopen_prediction_gf2=reopen_work,plaintext_bytes=wire,retained_state_bytes=state_bytes))
  expected=sorted(range(256),key=lambda i:hashlib.sha256(f'{PROTO}/case/{index}/input/{i}'.encode()).digest());expected=[i for i in expected if i not in observed_union][:32]
  need(reveal['inputs']==graded['inputs']==expected and not set(expected)&observed_union,'predeclared fresh inputs exclude every prior answer')
  reference,rank,isolated,cache=arm_results;need(rank['learning_gf2']==isolated['learning_gf2'] and rank['correct']==isolated['correct'],'isolated structural tie preserved')
  summaries.append(dict(index=index,mask=mask,bias=bias,arms=arm_results,rank_learning_gf2_saved=reference['learning_gf2']-rank['learning_gf2'],rank_retained_bytes_delta=rank['retained_state_bytes']-reference['retained_state_bytes'],fresh_inputs=expected))
 after=inventory(root);need(before==after,'closed evidence inventory unchanged')
 result=dict(schema='symbiote.independent-engine-evolution-fresh-audit/1',status='PASS_DATA_ONLY_FRESH_REUSE_AND_DECLARED_COSTS',source_commit=SOURCE,registration_sha256=REG,protocol_sha256=reg['protocol_sha256'],outer_report_sha256=sha(root/'evolution-report.json'),fresh_report_sha256=sha(root/'fresh-tasks/fresh-task-report.json'),consumer_sha256=sha(Path(__file__)),cases=summaries,source_sessions_checked=16,observations_checked=160,native_process_receipts_checked=process_count,full_case_predictions_checked=512,structural_predictions_correct=384,cache_abstentions=128,exact_gf2_work_replayed=True,prior_commitment_basis='Pinned supervisor control flow and hash links freeze->reveal->all-predictions->opening->grading; not an independent wall-clock attestation',local_executable_bytes_verified=args.local_bindings,local_source_files_verified=bool(args.repository),checked_file_hashes=checked,closed_evidence_inventory=before,closed_evidence_unchanged=True,native_processes_launched_by_audit=0,scientific_samples=0,independent_host_validation='OPEN_UNAVAILABLE',limits=['Four related width-eight affine wiring cases; no unfamiliar-domain proof.','Fresh suite transfers no artifact between agents; isolated structural learner ties.','GF2 computation savings trade against increased retained bytes; no whole-net or wall-time speedup conclusion.','Source/authentication, evaluator and native-counter integrity assume the trusted local frozen supervisor/engine; private bearer files were excluded.','Canonicalization, ledger assessment CPU, source/controller provisioning and grading costs are not converted into GF2 units.','No two-host, power-loss or new public-binary qualification is supplied by this audit.'])
 with args.output.open('x',encoding='utf-8',newline='\n')as stream:json.dump(result,stream,indent=2);stream.write('\n')
 print(json.dumps(dict(status=result['status'],output=str(args.output),sha256=sha(args.output),cases=[{'index':v['index'],'saved_learning_gf2':v['rank_learning_gf2_saved'],'retained_delta':v['rank_retained_bytes_delta'],'arms':v['arms']}for v in summaries]),indent=2))
if __name__=='__main__':main()
