"""Independent data-only Engine Evolution 002 prefix audit; never executes native code."""
import argparse, hashlib, json
from pathlib import Path

SOURCE = "bb1b88eaa771be5e201ccfcfe93840c6750eb9d7"
BASELINE = "0616f9a6dc6788078c623a3c2ed2ef237ae11de6"
REGISTRATION_SHA = "89241bf8b120508053a91966e57c02f70343a1f8a3e8aafe3d8a59ec1b385409"
BUILD_SHA = "53372d2db1d740375d5aeea5aa586c76a616d2d4e40bda839635ae19859e7bd9"
RESULT_SHA = "a0dcb9752c578041e745489b80198f42011fd788e377eed674e84b7d45f1cf68"

def require(condition, message):
    if not condition:
        raise ValueError(message)

def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False,
                      separators=(",", ":")).encode("utf-8")

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--run-root",type=Path,required=True)
    parser.add_argument("--build-proof",type=Path,required=True)
    parser.add_argument("--source-root",type=Path)
    parser.add_argument("--check-binaries",action="store_true")
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    require(not args.output.exists(),"audit output must be new; preserve earlier receipts")
    inputs=[]
    def read(path,label):
        raw=path.read_bytes()
        inputs.append(dict(name=label,path=str(path),bytes=len(raw),sha256=digest(raw)))
        return raw
    def load(path,label):
        return json.loads(read(path,label).decode("utf-8"))
    regraw=read(args.run_root/"registration.json","registration")
    require(digest(regraw)==REGISTRATION_SHA,"external registration pin differs")
    reg=json.loads(regraw)
    buildraw=read(args.build_proof,"build-proof")
    require(digest(buildraw)==BUILD_SHA,"build proof pin differs")
    build=json.loads(buildraw)
    outerraw=read(args.run_root/"evolution-report.json","closed-evolution-report")
    require(digest(outerraw)==RESULT_SHA,"closed outer result pin differs")
    outer=json.loads(outerraw)
    require(reg["schema"]=="symbiote.engine-evolution-registration/1" and reg["protocol"]=="SYMBIOTE-ENGINE-EVOLUTION-002","registration identity")
    require(reg["baseline_source"]==BASELINE and reg["source_commit"]==build["source_commit"]==outer["source_commit"]==SOURCE,"source pins")
    require(build["status"]=="PASS_BUILD_BYTES_PRESERVED" and all(x["exit_code"]==0 for x in build["commands"]),"build evidence")
    require(reg["prefix_profile"]==dict(histories=[0,16,64,256],captures=32),"registered history/capture shape")
    require(reg["bounds"]==dict(seconds=600,evidence_bytes=134217728) and not reg["automatic_retry"],"fixed resource/retry contract")
    require(reg["source_manifest"]==build["source_manifest"],"source manifests differ")
    manifest=reg["source_manifest"];body={k:v for k,v in manifest.items() if k!="sha256"}
    require(digest(canonical(body))==manifest["sha256"],"source manifest digest")
    require(sum(x["bytes"] for x in manifest["files"])==manifest["total_bytes"],"source byte census")
    source_files_verified=0
    if args.source_root:
        for row in manifest["files"]:
            raw=(args.source_root/row["path"]).read_bytes()
            require(len(raw)==row["bytes"] and digest(raw)==row["sha256"],"changed source member: "+row["path"])
            source_files_verified+=1
        protocol=read(args.source_root/"docs/ENGINE_EVOLUTION_PROTOCOL_002.md","frozen-protocol")
        require(digest(protocol)==reg["protocol_sha256"],"protocol pin")
    binaries=[]
    for role in ["native","observer","memory_test","service_test"]:
        row=reg[role]; require(row["sha256"]==build["binaries"][role]["sha256"],"binary registration/build mismatch")
        if args.check_binaries:
            raw=Path(row["path"]).read_bytes()
            require(digest(raw)==row["sha256"] and len(raw)==build["binaries"][role]["bytes"],"changed preserved binary bytes")
        binaries.append(dict(role=role,sha256=row["sha256"],actual_bytes_checked=args.check_binaries))
    proot=args.run_root/"prefix-profile"
    profileraw=read(proot/"profile-report.json","prefix-profile-report")
    profile=json.loads(profileraw)
    require(read(proot/"registration.json","profile-registration-copy")==regraw,"profile registration bytes changed")
    require(profile["registration"]==reg and profile["registration_sha256"]==REGISTRATION_SHA,"profile registration binding")
    require(profile["schema"]=="symbiote.prefix-profile/1" and profile["status"]=="PASS_EXACT_PREFIX_ENGINEERING","profile result type")
    require(profile["independent_scientific_samples"]==0 and profile["logical_graph_units_changed"] is False,"scope flags")
    require([h["history_events"] for h in profile["histories"]]==[0,16,64,256],"history completeness")
    results=[];prefix_checks=0
    for h in profile["histories"]:
        n=h["history_events"];path=proot/f"history-{n:03}"
        raw=read(path/"operations.jsonl",f"history-{n}-operations")
        lines=raw.splitlines(keepends=True);rows=[json.loads(line) for line in lines]
        require(len(rows)==n+1 and raw.endswith(b"\n"),"exact ledger count/termination")
        previous="0"*64
        for seq,row in enumerate(rows):
            require(row["sequence"]==seq and row["previous"]==previous,"operational receipt position")
            require(row["sha256"]==digest(canonical([seq,previous,row["payload"]])),"operational receipt hash")
            previous=row["sha256"]
        require(previous==h["journal_head_sha256"] and digest(raw)==h["journal_sha256"] and len(raw)==h["journal_bytes"],"ledger digest/head/bytes")
        genesis=rows[0]["payload"]
        require(genesis["owner_identity"]==h["owner"] and genesis["service_id"]=="prefix-profile/v1" and genesis["policy_digest"]=="a"*64,"operational owner/service/policy")
        owner=load(path/"operations-owner.json",f"history-{n}-registration")
        require(owner["owner_identity"]==h["owner"] and owner["genesis_sha256"]==rows[0]["sha256"],"operational genesis registration")
        read(path/"ledger.jsonl",f"history-{n}-store-ledger")
        events=[row["payload"] for row in rows[1:]]
        encoded=[canonical(event) for event in events]
        arrays=[canonical(events[:end]) for end in range(n+1)]
        expected=[digest(value) for value in arrays]
        payload_bytes=sum(map(len,encoded))
        for i,e in enumerate(events):
            d=e["decision"]
            require(e["event"]=="partner_decision_recorded" and d["decision_id"]==f"prefix-{i}" and d["context"]=="prefix-unit/v1" and d["selected_peer"]=="peer","bounded actual decision fixture")
            require(d["details"]["a"]["nested"]==[i,{}],"fixture nested sequence")
        setup=h["setup"]["work"]
        endpoints=list(range(64,n+1,64))
        if n and (not endpoints or endpoints[-1]!=n):endpoints.append(n)
        prefixes=[sum(map(len,lines[:end+1])) for end in endpoints]
        writes=len(lines[0])+sum(prefixes)
        clones=sum([len(lines[0])]+prefixes[:-1]) if n else 0
        require(setup["durable_bytes_written"]==writes and setup["committed_bytes_cloned"]==clones,"setup actual atomic write/copy costs")
        require(setup["event_visits"]==setup["hashed_bytes"]==setup["canonicalized_bytes"]==0 and not setup["saturated"],"setup reference had index disabled")
        arms={a["mode"]:a for a in h["arms"]};require(set(arms)=={"indexed","reference"},"both modes")
        summary={}
        for mode,arm in arms.items():
            cold=arm["cold_work"];warm=arm["after_captures_work"];end=arm["after_parity_work"]
            require(arm["prefixes"]==expected and arm["capture_digest"]==expected[-1] and arm["capture_count"]==32,"independent canonical prefix parity")
            prefix_checks+=len(expected)
            for w in [cold,warm,end]:
                require(w["ledger_bytes_read"]==len(raw) and w["durable_bytes_written"]==w["committed_bytes_cloned"]==0 and not w["saturated"],"cold/warm reads are immutable and bounded")
            if mode=="indexed":
                require(cold["event_visits"]==n and cold["canonicalized_bytes"]==payload_bytes and cold["hashed_bytes"]==(payload_bytes+2*n+1 if n else 2),"actual cold incremental byte count")
                for w in [warm,end]:
                    require(all(w[k]==cold[k] for k in ["event_visits","canonicalized_bytes","hashed_bytes"]),"warm cache serialized or hashed history")
                    require(w["reference_reads"]==w["reference_event_visits"]==w["reference_hashed_bytes"]==w["reference_canonicalized_bytes"]==0,"cached mode used reference work")
                require(cold["cache_reads"]==0 and warm["cache_reads"]==32 and end["cache_reads"]==32+n+1,"cached read count")
                require(cold["index_bytes"]>=32*(n+1)+arms["reference"]["cold_work"]["index_bytes"] and cold["index_bytes"]<=131072+4096,"bounded reserved index memory")
            else:
                for w in [cold,warm,end]:require(w["hashed_bytes"]==w["canonicalized_bytes"]==w["event_visits"]==w["cache_reads"]==0,"reference constructed index")
                require(cold["reference_reads"]==cold["reference_hashed_bytes"]==0,"cold reference did unexpected captures")
                require(warm["reference_reads"]==32 and warm["reference_event_visits"]==32*n and warm["reference_canonicalized_bytes"]==warm["reference_hashed_bytes"]==32*len(arrays[-1]),"actual reference capture work")
                require(end["reference_reads"]==32+n+1 and end["reference_event_visits"]==32*n+n*(n+1)//2,"reference all-prefix visits")
                require(end["reference_canonicalized_bytes"]==end["reference_hashed_bytes"]==32*len(arrays[-1])+sum(map(len,arrays)),"actual reference all-prefix bytes")
            summary[mode]=dict(cold_ms=arm["cold_open_elapsed_ns"]/1e6,capture32_ms=arm["capture_elapsed_ns"]/1e6,
                parity_ms=arm["all_prefixes_elapsed_ns"]/1e6,close_ms=arm["close_elapsed_ns"]/1e6,
                cold_capture_close_ms=sum(arm[k] for k in ["cold_open_elapsed_ns","capture_elapsed_ns","close_elapsed_ns"])/1e6,
                setup_cold_capture_close_ms=(h["setup"]["elapsed_ns"]+sum(arm[k] for k in ["cold_open_elapsed_ns","capture_elapsed_ns","close_elapsed_ns"]))/1e6,
                index_bytes=cold["index_bytes"],cold_canonicalized_bytes=cold["canonicalized_bytes"],cold_hashed_bytes=cold["hashed_bytes"],
                capture_canonicalized_bytes=warm["reference_canonicalized_bytes"]-cold["reference_canonicalized_bytes"],
                capture_hashed_bytes=warm["reference_hashed_bytes"]-cold["reference_hashed_bytes"])
        results.append(dict(history_events=n,distinct_prefixes=n+1,canonical_full_array_bytes=len(arrays[-1]),
                            setup_durable_bytes=writes,setup_copied_bytes=clones,setup_ms=h["setup"]["elapsed_ns"]/1e6,arms=summary))
    require(outer["registration_sha256"]==REGISTRATION_SHA and outer["status"]=="PASS_ENGINEERING_ONLY","closed outer result")
    require(outer["elapsed_seconds"]<=600 and outer["automatic_retry"] is False,"whole-workload time/retry limit")
    process=next(p for p in outer["process_calls"] if p["label"]=="prefix-profile")
    rawprocess=load(args.run_root/"processes"/process["process_receipt"],"prefix-process-receipt")
    require(rawprocess==process and process["exit_code"]==0 and process["cleanup_verified"] and not process["output_truncated"],"actual closed process receipt")
    stdout=read(args.run_root/"processes"/process["stdout"],"prefix-process-stdout")
    stderr=read(args.run_root/"processes"/process["stderr"],"prefix-process-stderr")
    require(digest(stdout)==process["stdout_sha256"] and digest(stderr)==process["stderr_sha256"],"process output bytes")
    require(process["argv"][0]==reg["memory_test"]["path"] and "--ignored" in process["argv"] and "--exact" in process["argv"],"registered executable/test selection")
    marker=next(line.split("SYMBIOTE_PREFIX_PROFILE_JSON ",1)[1] for line in stdout.decode("utf-8").splitlines() if "SYMBIOTE_PREFIX_PROFILE_JSON " in line)
    marker=json.loads(marker)
    profile_bytes=sum(p.stat().st_size for p in proot.rglob("*") if p.is_file())
    run_bytes=sum(p.stat().st_size for p in args.run_root.rglob("*") if p.is_file())
    require(marker["sha256"]==digest(profileraw) and marker["evidence_bytes"]==profile_bytes and marker["whole_elapsed_ns"]<=600*10**9,"closed profile census/time binding")
    require(run_bytes<=reg["bounds"]["evidence_bytes"],"whole raw evidence census exceeds128MiB")
    result=dict(schema="symbiote.engine-evolution-prefix-independent-audit/1",status="PASS_DATA_ONLY_PREFIX_REPLAY",
        source_commit=SOURCE,registration_sha256=REGISTRATION_SHA,build_proof_sha256=BUILD_SHA,
        source_manifest_sha256=manifest["sha256"],source_files_current_bytes_verified=source_files_verified,binaries=binaries,
        profile_sha256=digest(profileraw),outer_result_sha256=RESULT_SHA,
        distinct_prefixes_recomputed=340,arm_prefix_comparisons=prefix_checks,captures_reported_and_counter_checked=256,
        profile_closed_elapsed_ms=marker["whole_elapsed_ns"]/1e6,prefix_process_seconds=process["elapsed_seconds"],
        whole_workload_seconds=outer["elapsed_seconds"],profile_evidence_bytes=profile_bytes,whole_evidence_bytes=run_bytes,
        bounds=reg["bounds"],histories=results,raw_inputs=inputs,
        method="Independent Python standard-library recomputation of canonical arrays, SHA256 receipt chains, prefix values, every byte/event counter and setup write/copy lengths. No native invocation, source modification, project-tool import or campaign repeat.",
        limitations=["Only OperationalJournal boundary-digest access is timed; complete capture_local_execution and full cognitive startup/loop performance are not measured.",
            "One predetermined observation per history/mode on one PC; filesystem/order/clock noise prevents statistical or general hardware speed claims.",
            "Counter memory is inline-plus-reserved prefix storage, not peak process memory; elapsed spans are not exclusive CPU.",
            "Native work and cleanup remain instrumented process-receipt evidence, not fresh independent OS observations.",
            "Historical graph losses and oracle prices are unchanged; no whole-agent/reciprocal economic benefit or independent-host claim follows.",
            "Reference is the retained full-serialization path in the same new executable, not a rerun of the previously published release."])
    result["audit_script_sha256"]=digest(Path(__file__).read_bytes())
    args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")
    print(json.dumps(dict(status=result["status"],output=str(args.output),sha256=digest(args.output.read_bytes()),prefixes=prefix_checks,whole_bytes=run_bytes)))
    for h in results:print(json.dumps(h))

if __name__=="__main__":main()
